var today = 'today';

console.log('date is', timestamp());
console.log('today is', today);

function timestamp() {
    var today = Date();
    return today;
}