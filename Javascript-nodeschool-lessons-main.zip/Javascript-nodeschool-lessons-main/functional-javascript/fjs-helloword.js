function upperCaser(palavra){
  return palavra.toUpperCase();
}

module.exports = upperCaser
