function repeat(operation, num) {
  function operation(){
    num += 1
    return num
  }
}

module.exports = repeat
