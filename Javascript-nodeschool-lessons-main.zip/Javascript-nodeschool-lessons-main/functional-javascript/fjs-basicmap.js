function doubleAll(numbers) {
 result = numbers.map(x => x*2)
  return result
}

module.exports = doubleAll
