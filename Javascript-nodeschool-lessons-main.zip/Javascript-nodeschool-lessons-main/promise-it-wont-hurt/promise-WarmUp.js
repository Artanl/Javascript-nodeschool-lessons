setTimeout(function () {
    console.log('TIMED OUT!')
}, 300)