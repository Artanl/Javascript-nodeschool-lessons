console.log(`Hello ${process.argv[2]}`)
