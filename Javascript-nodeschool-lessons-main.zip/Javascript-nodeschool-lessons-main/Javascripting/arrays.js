const pizzaTopping = ['tomato sauce', 'cheese', 'pepperoni']

console.log(pizzaTopping)
