function math(m1, m2, m3) {
  let a = m2 * m3
  a = a + m1
  return a
}

console.log(math(53, 61, 67))
